import logging, datetime

import azure.functions as func
from azure.servicebus import ServiceBusClient, ServiceBusMessage


CONNECTION_STR = os.environ['SERVICE_BUS_CONNECTION_STR']
QUEUE_NAME = os.environ["SERVICE_BUS_QUEUE_NAME"]


def send_single_message(sender):
    message = ServiceBusMessage("Single Message")
    sender.send_messages(message)


def send_batch_message(sender, messages):
    batch_message = sender.create_message_batch()
    for i in range(messages):
        try:
            batch_message.add_message(messages[i])
        except ValueError:
            # ServiceBusMessageBatch object reaches max_size.
            # New ServiceBusMessageBatch object can be created here to send more data.
            break
    sender.send_messages(batch_message)


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger has received a new scheduling request.')

    current_time = datetime.now(timezone.utc)
    
    subject = req.params.get('subject')
    count = req.params.get('count')
    iteration = req.params.get('iteration')
    frequency = req.params.get('frequency') # in "h" "m" "s"

    for i in int(count):
        switch (frequency):
            case "h":

        ServiceBusMessage(
            "FnSvcBusScheduler",
            session_id=subject
            
        )


    servicebus_client = ServiceBusClient.from_connection_string(conn_str=CONNECTION_STR, logging_enable=True)
    with servicebus_client:
        sender = servicebus_client.get_queue_sender(queue_name=QUEUE_NAME)
        with sender:
            send_single_message(sender)
            send_a_list_of_messages(sender)
            send_batch_message(sender)

    print("Send message is done.")





    ServiceBusMessage(
       "Hello World!!",
       session_id="MySessionID",
       application_properties={'data': 'custom_data'},
       time_to_live=datetime.timedelta(seconds=30),
       label='MyLabel'
   )
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
        except ValueError:
            pass
        else:
            name = req_body.get('name')

    if name:
        return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
    else:
        return func.HttpResponse(
             "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
             status_code=200
        )
